## Instructions 

* $ ng new <app-name> 
* go to http://localhost:4200/

## Notes


I solemnly swear that I completed this exercise on my own in approximately 47 minutes. 
Please note that approx 17 min was used to setup the app and download app dependencies (node_modules)


Notes/nice to have:
* bare minimum requirements
* no css
* no unit test
* only total cart cost is computed, items and no. of items in cart not saved/displayed
